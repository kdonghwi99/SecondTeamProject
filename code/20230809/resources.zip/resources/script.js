/**
 * /resources/js/script.js
 */

 function delChk() {
	 // 게시물 삭제 시 확인 메서드
	 if(confirm('해당 글을 삭제하시겠습니까?')) {
		$('form').attr('action', './NoticeRemove.do').submit();
		// form의 action 경로를 ./NoticeRemove.do로 바꾸고 submit하기 
 	}
 }
 
function updChk() {
	// 게시물 수정 시 확인 메서드
    if (confirm("해당 글을 수정하시겠습니까?")) {
        document.querySelector("form").submit();
        // 확인 누르면 form의 경로로 submit하기
    }
}

function insChk() {
	// 게시물 등록 시 확인 메서드
    if (confirm("글을 등록하시겠습니까?")) {
        document.querySelector("form").submit();
        // 확인 누르면 form의 경로로 submit하기
    }
}