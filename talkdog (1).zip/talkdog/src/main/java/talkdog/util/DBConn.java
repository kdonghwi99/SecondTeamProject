package talkdog.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConn {
	private static Connection con; 
	public DBConn() {} //1. 외부에서 접근 불가능한 기본 생성자 작성
	
	// 2. Conection 객체가 null인 경우만 객체를 반환하고 공유하는 메서드
	// getConnection()작성(접근 제한 x)
	public static Connection getConnection() {
		//         생성      
		//connection객체는 많이 잡아먹음, 계속 new로 불르면 인스턴스가 계속 쌓임
		//connectionpool이란걸로 관리, 한개의 커넥션을 공유해서 사용하는 것 = 싱글톤
		if(con == null) { //이부분은 생성이 안되었을때
			
			String driver = "oracle.jdbc.OracleDriver";
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String username = "talkdog";
			String password = "1111";
			
				
				try {
					
					Class.forName(driver);
					con = DriverManager.getConnection(url, username, password);
					System.out.println("con.ok");
					//이 두개가 핵심, 불러오면 
					//이게 객체 지향 프로그래밍: 코드를 부품화하고 재사용성을 높이는 것 

				} catch (SQLException e) { //catch 구문만 추가

					e.printStackTrace(); //예외가 발생하면 이걸 출력
				}
				
				catch (ClassNotFoundException e) { //
				
					e.printStackTrace();
			}
		}
			return con;
			
	}
	
	
	//4 preparpedstatement 객체를 매개 변수로 받아서
	// 닫는 메서드 close() 작성 (접근 제한x)
	public static void close(PreparedStatement pstmt) {
		//공유해서 쓸거니까 static
		
		try {
			if (pstmt != null)
				pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	//5 preparedstatement, resultset객체를 매개변수로 받아
	//닫는 공유 메서드 close() 작성(접근 제한x)
	//rset과 pstmt한번에 닫기
	public static void close( ResultSet rset, PreparedStatement pstmt) {
		 //닫는 순서 꼭 지켜야함, DAO에서 pstmt > rset 순으로 열었기 떄문에
		try {
			if(rset != null) rset.close();
			if(pstmt != null) pstmt.close();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	//6 매개변수 받지 않고 connection class의 객체 con(위에)을 종료하는
	//공유 메소드 close() 작성
	//매개변수: 메소드 실행시 필요한 데이터를 받아오는 값
    public static void close() { //conn은 위에서 불러왔기 떄문에 괄호안에 안써도됨
		
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
