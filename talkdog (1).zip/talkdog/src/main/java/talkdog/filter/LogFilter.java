//ckage talkdog.filter;
//
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpFilter;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebFilter("/*")
//public class LogFilter extends HttpFilter implements Filter {
//
//	
//	private static final long serialVersionUID = 1L;
//	private PrintWriter pw;
//	private SimpleDateFormat dateTimeFmt;
//	
//	// 로그 기록용 파일 닫기
//	public void destroy() {
//		System.out.println("-- MARKET ACCESS LOGGING END --");
//		if(pw != null) {
//			pw.close();
//		}
//	}
//
//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//		HttpServletRequest req = (HttpServletRequest)request;
//		HttpServletResponse res = (HttpServletResponse)response;
//		// 요청 URI 및 쿼리 스트링을 로그 기록 파일에 쓰기(pw.println)
//		// 접속 시간 : ~~~
//		String time1 = getDateTime();
//		pw.println("접속 시간 : " + time1);
//		// 클라이언트 IP : ~~~
//		pw.println("클라이언트 IP : " + request.getRemoteAddr()); 
//		// 요청 URL : ~~~(요청 URI + 쿼리스트링(있는 경우))
//		pw.println("요청 URL : " + req.getRequestURI() + req.getQueryString());
//		
//		chain.doFilter(request, response);
//
//		// 처리 완료 : ~~~(시간)
//		String time2 = getDateTime();
//		pw.println("처리 완료 : " + time2);
//		// 소요 시간 : ~~~
////		pw.println("소요 시간 : " + time1 - time2);
//		pw.println("----------------------------------------------");		
//	}
//	
//	// 로그 기록용 파일 생성
//	public void init(FilterConfig fConfig) throws ServletException {
//		System.out.println("-- MARKET ACCESS LOGGING START --");
//		dateTimeFmt = new SimpleDateFormat("yyyy.MM.dd hh:mm:ss");
//		
//		String path = fConfig.getServletContext().getRealPath("/log/");
//		String file = getDateTime().substring(0, 10) + ".log";
//		System.out.println(path + file);
//		
//		try {
//			FileWriter fw = new FileWriter(path + file, true);	// append 모드로 파일 객체 생성
//			pw = new PrintWriter(fw, true);	// auto flush mode
//		} catch(Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public String getDateTime() {
//		return dateTimeFmt.format(new Date());
//	}
//}
