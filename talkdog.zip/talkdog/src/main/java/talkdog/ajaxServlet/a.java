package talkdog.ajaxServlet;

public class a {

}
